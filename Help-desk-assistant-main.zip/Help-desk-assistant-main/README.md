# Help-desk-assistant
Basically the main problem in organization is all employees are bus working so no body is free to help the freshers so to avoide this inconvenience we have build an chat-bot which will help them guide
